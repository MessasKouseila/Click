La fonction magique __call nous permet  d'executer les fontions findAll FindOneByutilisateur 
. En effet cette fonction est appele lorque la methode n'existe pas on recupere les requetes (c'est a dire la methode appelee) et les parametres a fin d' effectuer les requetes
