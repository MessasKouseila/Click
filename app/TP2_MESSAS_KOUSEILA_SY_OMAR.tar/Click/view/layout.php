<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
    <link href="css/ajout.css" rel="stylesheet"/>
	<title>Ton appli !</title>
   
</head>
<body>
<div class="container-fluid">
<script src="js/jquery.js"></script>
	<div id="notify">
	<?php $var = $context->notify;
	if(isset($var)) {
		echo $context->notify;
	} ?>
	</div>
<!-- j'ai le droit de mettre des commentaires dans mon fichier HTML -->
	<?php include($template_view); ?>
</div>    
</body>
</html>
