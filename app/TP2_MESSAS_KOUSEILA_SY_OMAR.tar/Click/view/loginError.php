<div class="row text-center">
  <form class="form-inline" method="post" action="">
    <fieldset>
      <div class="row">
        <div class="col-xs-4 col-xs-offset-4" style="margin-top:20px;text-align:center"><h3 class="bg-primary"><legend>CONNEXION</legend></h3></div>
      </div> 
      <div class="form-group">
        <label for="login">Login </label>
        <input type="text" class="form-control" name="login" placeholder="unLogin">
        <label for="passWord">PassWord </label>
        <input type="password" class="form-control" name="passWord">
      </div>
      <button type="submit" class="btn btn-danger">Entrer</button>
    </fieldset>
  </form> 
</div>