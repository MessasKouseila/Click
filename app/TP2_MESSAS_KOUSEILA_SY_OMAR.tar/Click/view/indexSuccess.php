C'est l'action par défaut ! 
<a href=Click.php?action=logout>Deconnectez vous !</a>
