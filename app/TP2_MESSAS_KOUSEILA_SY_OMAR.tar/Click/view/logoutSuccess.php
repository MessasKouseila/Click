Vous etes deconnecte !
<a href="Click.php?action=login"> Login </a>
